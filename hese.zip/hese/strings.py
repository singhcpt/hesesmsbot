NEW_USER_MESSAGE = "Hello! This is the first time we have seen your number. We'll need to do some setup. First, What username do you want?"

SETUP_MESSAGE2 = "What news would you like to know about ((1)Sales, (2)Social, (3)Criminal, (4)Political)? put commas between choices."

SETUP_MESSAGE3 = "Thank you! You're all set up"

REPORT_MESSAGE1 = "What topic are you reporting on? (1)Sales, (2)Social, (3)Criminal, (4)Political."

REPORT_MESSAGE2 = "In 5 words or less what is happening?"

REPORT_ERROR1 = "5 words or less please."

REPORT_MESSAGE3 = "Great! now send us your location by using attach and choosing location"

#* automatic submission not yet supported - TODO
REPORT_MESSAGE4 = "Thanks! now, optionally, you can add a short description. if you don't your report will automatically be submitted*."

REPORT_MESSAGE5 = "Success! Your report has ben submitted!"

LIST_MESSAGE1 = "What topic do you want to see reports about? (1)Sales, (2)Social, (3)Criminal, (4)Political."

LIST_MESSAGE2 = "Here are the current reports about "

LIST_MESSAGE3 = "Type the number of an event you want to know more about."

MAPS_FORMAT_STRING = "http://maps.google.com/maps?f=q&q="
