from bot import *
exit == ""
while(exit != "#exit"):
    i = input()
    print(processText(i, 123))

