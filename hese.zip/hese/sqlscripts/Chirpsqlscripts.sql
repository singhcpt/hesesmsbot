CREATE DATABASE chirpdb;

create table Events
(
    event_id    int not null,
    headline    VARCHAR(255),
    description VARCHAR(255),
    date        DATE,
    event_type  int,
    latitude    FLOAT,
    longitude   FLOAT
);

create table Users
(
    user_id           int not null,
    username          VARCHAR(255),
    reliability_score FLOAT,
    base_latitude     FLOAT,
    base_longitude    FLOAT,
    preferences       int
);